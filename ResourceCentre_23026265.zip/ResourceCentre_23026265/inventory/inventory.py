from inventory.camera import Camera
class Inventory():
  pass
  def __init__(self):
    self.cameraList = []
  
  def addCamera(self, assetTag, description, opticalzoom):
# Check for correct values
    correct = True
    if len(assetTag)==0 or len(description)==0 or opticalzoom<0:
      correct = False
      error_message = "Incorrect values."
# Refactor (C): Extract long methods to findCamera(assetTag), 
# return the found camera, return None if not found.
# **Don't forget to create test cases for this new method.
# Check for existing camera
    notExist = True
    for c in self.cameraList:
      currentTag = c.getAssetTag()
      if currentTag == assetTag:
        notExist = False
        error_message = "Asset already exists."
    if correct and notExist:
      new_camera = Camera(assetTag, description, opticalzoom)
      self.cameraList.append(new_camera)
      return True
    else:
      print(error_message)
      return False